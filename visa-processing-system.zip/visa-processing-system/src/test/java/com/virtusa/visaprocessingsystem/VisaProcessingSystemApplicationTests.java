package com.virtusa.visaprocessingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisaProcessingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
